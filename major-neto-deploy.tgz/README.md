# Major Neto — Central de campanhas

MVP de um painel para criar, agendar e acompanhar disparos de texto, imagem e vídeo no WhatsApp, com publicação opcional no Instagram via Meta Graph API.

O painel tem somente três áreas: **Campanhas** (conteúdo separado para WhatsApp e Instagram), **WhatsApp** (sessão WPPConnect e importação de contatos Excel/CSV) e **Instagram** (validação da conta profissional pelo Meta). Não há campanhas, contatos ou credenciais pré-preenchidos.

As campanhas são persistidas em SQLite no arquivo `data/major-neto.sqlite`. Configure `DATABASE_PATH` para mudar o local; o arquivo fica fora do Git e deve ser incluído no backup da VPS.

## Rodar localmente

1. Instale Node.js 18+.
2. Copie `.env.example` para `.env`.
3. Execute `npm install`.
4. Execute `npm start` e abra `http://localhost:3000`.

O projeto inicia em `DEMO_MODE=true`, que permite validar o fluxo sem enviar mensagens. Para conectar, configure `WPP_CONNECT_URL`, `WPP_CONNECT_SESSION`, `WPP_CONNECT_TOKEN`, `META_IG_USER_ID` e `META_ACCESS_TOKEN`, e altere `DEMO_MODE=false`.

## Integrações

- WPPConnect Server: texto usa `POST /api/{session}/send-message`; imagem usa `send-image`; vídeo usa `send-file`, todos com `Authorization: Bearer`.
- Meta: o servidor cria um container em `/{ig-user-id}/media` e publica em `/{ig-user-id}/media_publish`. A mídia precisa ter uma URL pública quando estiver em modo conectado (`media.publicUrl`).

## Cadência e personalização

Na criação da campanha, `delayMs` controla o intervalo entre envios (de 1 a 600 segundos). A variável `{{nome}}` é substituída pelo nome do contato. A personalização por IA é opcional e usa `AI_API_KEY`, `AI_BASE_URL` e `AI_MODEL` no servidor; ela não deve ser usada para contornar políticas, limites ou bloqueios de plataformas. Envie somente para contatos que autorizaram a comunicação e mantenha uma opção de saída/opt-out.

## Próximos passos de produção

Este MVP mantém o histórico em memória e recebe mídia em base64 para facilitar o primeiro teste. Antes de produção, adicione autenticação, persistência, fila com retry/idempotência, armazenamento de mídia (S3/R2), rate limit compartilhado, webhook de status e uma tela de configuração protegida para as credenciais.

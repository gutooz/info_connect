const fs = require('node:fs');
const path = require('node:path');
const Database = require('better-sqlite3');

function createCampaignStore(databasePath) {
  const resolvedPath = path.resolve(databasePath);
  fs.mkdirSync(path.dirname(resolvedPath), { recursive: true });
  const database = new Database(resolvedPath);
  database.pragma('journal_mode = WAL');
  database.pragma('busy_timeout = 5000');
  database.exec(`
    CREATE TABLE IF NOT EXISTS campaigns (
      id TEXT PRIMARY KEY,
      payload TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);

  const saveStatement = database.prepare(`
    INSERT INTO campaigns (id, payload, updated_at)
    VALUES (@id, @payload, datetime('now'))
    ON CONFLICT(id) DO UPDATE SET
      payload = excluded.payload,
      updated_at = datetime('now')
  `);
  const listStatement = database.prepare('SELECT payload FROM campaigns ORDER BY created_at DESC, rowid DESC');

  return {
    list() {
      return listStatement.all().map((row) => JSON.parse(row.payload));
    },
    save(campaign) {
      if (!campaign || !campaign.id) throw new Error('Campanha inválida para persistência.');
      saveStatement.run({ id: String(campaign.id), payload: JSON.stringify(campaign) });
    },
    close() {
      if (database.open) database.close();
    }
  };
}

module.exports = { createCampaignStore };

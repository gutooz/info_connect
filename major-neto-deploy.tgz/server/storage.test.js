const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const test = require('node:test');
const { createCampaignStore } = require('./storage');

test('persiste campanhas depois de fechar e reabrir o banco', () => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'major-neto-'));
  const databasePath = path.join(directory, 'campaigns.sqlite');
  const campaign = {
    id: 'campaign-1',
    name: 'Campanha persistida',
    status: 'sending',
    statusLabel: 'Enviando',
    sent: 1,
    audience: 2,
    recipients: [{ name: 'Ana', phone: '5511999999999' }],
    channels: { whatsapp: { type: 'text', message: 'Olá {{nome}}', media: null } },
    createdAt: 'Agora'
  };

  const firstStore = createCampaignStore(databasePath);
  firstStore.save(campaign);
  firstStore.close();

  const secondStore = createCampaignStore(databasePath);
  assert.deepEqual(secondStore.list(), [campaign]);
  secondStore.close();
  fs.rmSync(directory, { recursive: true, force: true });
});

const express = require('express');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const ExcelJS = require('exceljs');
require('dotenv').config();
const { createCampaignStore } = require('./storage');

const app = express();
const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '127.0.0.1';
const demoMode = process.env.DEMO_MODE !== 'false';
const databasePath = process.env.DATABASE_PATH || path.join(__dirname, '..', 'data', 'major-neto.sqlite');
const campaignStore = createCampaignStore(databasePath);
const campaigns = campaignStore.list();
const contacts = [];
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } });
const aiConfigured = Boolean(process.env.AI_API_KEY || process.env.OPENAI_API_KEY);

app.disable('x-powered-by');
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});
app.use(express.json({ limit: '24mb' }));
app.use(express.static(path.join(__dirname, '..', 'public')));

function onlyDigits(value) {
  return String(value || '').replace(/\D/g, '');
}

function wait(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function normalizeRecipients(recipients) {
  if (!Array.isArray(recipients)) return [];
  return recipients
    .map((recipient) => {
      if (typeof recipient === 'string') return { phone: onlyDigits(recipient), name: 'Contato' };
      return { phone: onlyDigits(recipient.phone), name: String(recipient.name || 'Contato').slice(0, 80) };
    })
    .filter((recipient) => recipient.phone.length >= 8 && recipient.phone.length <= 15);
}

function normalizeContact(name, phone) {
  const normalizedPhone = onlyDigits(phone);
  if (!normalizedPhone || normalizedPhone.length < 8 || normalizedPhone.length > 15) return null;
  return { id: crypto.randomUUID(), name: String(name || 'Contato').trim().slice(0, 80) || 'Contato', phone: normalizedPhone };
}

function parseCsv(buffer) {
  const lines = buffer.toString('utf8').split(/\r?\n/).filter(Boolean);
  if (!lines.length) return [];
  const headers = lines.shift().split(/[;,]/).map((header) => header.trim().toLowerCase());
  const nameIndex = headers.findIndex((header) => ['nome', 'name'].includes(header));
  const phoneIndex = headers.findIndex((header) => ['telefone', 'phone', 'whatsapp', 'celular'].includes(header));
  if (nameIndex < 0 || phoneIndex < 0) throw new Error('A planilha precisa ter as colunas nome e telefone.');
  return lines.map((line) => {
    const values = line.split(/[;,]/).map((value) => value.trim().replace(/^"|"$/g, ''));
    return normalizeContact(values[nameIndex], values[phoneIndex]);
  }).filter(Boolean);
}

async function parseSpreadsheet(file) {
  const extension = path.extname(file.originalname).toLowerCase();
  if (extension === '.csv') return parseCsv(file.buffer);
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(file.buffer);
  const worksheet = workbook.worksheets[0];
  if (!worksheet) return [];
  const headerRow = worksheet.getRow(1).values.map((value) => String(value || '').trim().toLowerCase());
  const nameIndex = headerRow.findIndex((header) => ['nome', 'name'].includes(header));
  const phoneIndex = headerRow.findIndex((header) => ['telefone', 'phone', 'whatsapp', 'celular'].includes(header));
  if (nameIndex < 0 || phoneIndex < 0) throw new Error('A planilha precisa ter as colunas nome e telefone.');
  const parsed = [];
  worksheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return;
    const contact = normalizeContact(row.getCell(nameIndex + 1).value, row.getCell(phoneIndex + 1).value);
    if (contact) parsed.push(contact);
  });
  return parsed;
}

function unwrapWppResponse(payload) {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.response)) return payload.response;
  if (Array.isArray(payload?.data)) return payload.data;
  return [];
}

function normalizeWppContact(contact) {
  const rawId = typeof contact.id === 'string' ? contact.id : contact.id?.user;
  const phone = contact.phone || contact.number || rawId;
  const name = contact.name || contact.formattedName || contact.pushname || contact.shortName || 'Contato';
  return normalizeContact(name, String(phone || '').split('@')[0]);
}

function validateCampaign(input) {
  const name = String(input.name || '').trim().slice(0, 120);
  const wppSession = String(input.wppSession || process.env.WPP_CONNECT_SESSION || '').trim().replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 60);
  const delayMs = Number(input.delayMs ?? 3000);
  const aiPersonalization = Boolean(input.aiPersonalization);
  const whatsapp = input.channels?.whatsapp || input;
  const instagram = input.channels?.instagram || null;
  const type = ['text', 'image', 'video'].includes(whatsapp.type) ? whatsapp.type : 'text';
  const message = String(whatsapp.message || '').trim().slice(0, 4096);
  const recipients = normalizeRecipients(input.recipients);
  if (!name) throw new Error('Informe um nome para a campanha.');
  if (!message && !whatsapp.media?.base64) throw new Error('Adicione um texto ou arquivo de mídia para o WhatsApp.');
  if (!recipients.length) throw new Error('Selecione ao menos um contato válido.');
  if (recipients.length > 500) throw new Error('O limite desta versão é de 500 contatos por campanha.');
  if (type !== 'text' && !whatsapp.media?.base64) throw new Error('Envie o arquivo da campanha.');
  if (!Number.isInteger(delayMs) || delayMs < 1000 || delayMs > 600000) throw new Error('O intervalo deve ficar entre 1 e 600 segundos.');
  if (aiPersonalization && !aiConfigured) throw new Error('Configure AI_API_KEY no .env para ativar a personalizaÃ§Ã£o por IA.');
  if (input.scheduledAt && Number.isNaN(Date.parse(input.scheduledAt))) throw new Error('A data de agendamento é inválida.');
  return { name, type, message, recipients, wppSession, delayMs, aiPersonalization, channels: { whatsapp: { type, message, media: whatsapp.media || null }, instagram: instagram ? { type: instagram.type, message: String(instagram.message || '').trim().slice(0, 4096), media: instagram.media || null } : null } };
}

async function wppRequest(endpoint, body, sessionOverride) {
  const base = String(process.env.WPP_CONNECT_URL || '').replace(/\/$/, '');
  const session = encodeURIComponent(sessionOverride || process.env.WPP_CONNECT_SESSION || '');
  if (!base || !session || !process.env.WPP_CONNECT_TOKEN) {
    throw new Error('WPPConnect não está configurado.');
  }
  const response = await fetch(`${base}/api/${session}/${endpoint}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${process.env.WPP_CONNECT_TOKEN}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`WPPConnect respondeu ${response.status}: ${detail.slice(0, 160)}`);
  }
  return response.json().catch(() => ({}));
}

async function wppGet(endpoint, sessionOverride) {
  const base = String(process.env.WPP_CONNECT_URL || '').replace(/\/$/, '');
  const session = encodeURIComponent(sessionOverride || process.env.WPP_CONNECT_SESSION || '');
  if (!base || !session || !process.env.WPP_CONNECT_TOKEN) throw new Error('WPPConnect nÃ£o estÃ¡ configurado.');
  const response = await fetch(`${base}/api/${session}/${endpoint}`, {
    headers: { Authorization: `Bearer ${process.env.WPP_CONNECT_TOKEN}` }
  });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`WPPConnect respondeu ${response.status}: ${detail.slice(0, 160)}`);
  }
  return response.json().catch(() => ({}));
}

function extractAiText(result) {
  if (typeof result.output_text === 'string') return result.output_text.trim();
  return (result.output || []).flatMap((item) => item.content || []).filter((item) => item.type === 'output_text').map((item) => item.text).join('').trim();
}

async function personalizeMessage(message, recipient) {
  const withName = message.replace(/\{\{\s*nome\s*\}\}/gi, recipient.name || '');
  if (!aiConfigured) return withName;
  const baseUrl = String(process.env.AI_BASE_URL || 'https://api.openai.com/v1').replace(/\/$/, '');
  const apiKey = process.env.AI_API_KEY || process.env.OPENAI_API_KEY;
  const model = process.env.AI_MODEL || 'gpt-4o-mini';
  const response = await fetch(`${baseUrl}/responses`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model,
      store: false,
      instructions: 'Personalize a mensagem para um contato que autorizou receber comunicações. Preserve oferta, valores, links, fatos e instruções de opt-out. Use o nome apenas quando natural. Não crie urgência falsa, não faça alegações novas e não tente contornar filtros ou políticas de plataformas. Retorne somente a mensagem final em português.',
      input: `Nome do contato: ${recipient.name || 'cliente'}\nMensagem-base:\n${withName}`,
      max_output_tokens: 300,
      temperature: 0.4
    }),
    signal: AbortSignal.timeout(20000)
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error?.message || 'A IA não conseguiu personalizar a mensagem.');
  const personalized = extractAiText(result);
  if (!personalized || personalized.length > 4096) throw new Error('A IA retornou uma mensagem inválida.');
  return personalized;
}

async function sendToWhatsApp(campaign) {
  const content = campaign.channels?.whatsapp || campaign;
  const session = campaign.wppSession || process.env.WPP_CONNECT_SESSION;
  let sent = 0;
  for (const [index, recipient] of campaign.recipients.entries()) {
    if (index > 0) await wait(campaign.delayMs || 3000);
    let message = content.message;
    if (campaign.aiPersonalization && content.message) {
      try { message = await personalizeMessage(content.message, recipient); } catch (_error) { campaign.aiFallbacks = (campaign.aiFallbacks || 0) + 1; message = content.message.replace(/\{\{\s*nome\s*\}\}/gi, recipient.name || ''); }
    } else {
      message = content.message.replace(/\{\{\s*nome\s*\}\}/gi, recipient.name || '');
    }
    if (demoMode) {
      await new Promise((resolve) => setTimeout(resolve, 40));
    } else if (content.type === 'text') {
      await wppRequest('send-message', { phone: recipient.phone, message }, session);
    } else {
      await wppRequest(content.type === 'image' ? 'send-image' : 'send-file', {
        phone: recipient.phone,
        filename: content.media.name || `campanha.${content.type === 'image' ? 'jpg' : 'mp4'}`,
        caption: message,
        base64: content.media.base64
      }, session);
    }
    sent += 1;
  }
  return sent;
}

async function publishToMeta(campaign) {
  if (demoMode) {
    await new Promise((resolve) => setTimeout(resolve, 180));
    return { id: `demo-meta-${Date.now()}` };
  }
  const content = campaign.channels?.instagram || campaign;
  if (content.type === 'text') throw new Error('A publicação do Instagram precisa de uma imagem ou vídeo.');
  const graphVersion = process.env.META_GRAPH_VERSION || 'v23.0';
  const userId = process.env.META_IG_USER_ID;
  const accessToken = process.env.META_ACCESS_TOKEN;
  const publicUrl = content.media?.publicUrl;
  if (!userId || !accessToken || !publicUrl) {
    throw new Error('Meta exige META_IG_USER_ID, META_ACCESS_TOKEN e uma URL pública para a mídia.');
  }
  const params = new URLSearchParams({
    access_token: accessToken,
    caption: content.message || ''
  });
  params.set(content.type === 'video' ? 'media_type' : 'image_url', content.type === 'video' ? 'REELS' : publicUrl);
  if (content.type === 'video') params.set('video_url', publicUrl);
  const createResponse = await fetch(`https://graph.facebook.com/${graphVersion}/${userId}/media`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: params
  });
  const container = await createResponse.json();
  if (!createResponse.ok || !container.id) throw new Error(container.error?.message || 'Não foi possível criar a publicação no Meta.');
  const publishParams = new URLSearchParams({ creation_id: container.id, access_token: accessToken });
  const publishResponse = await fetch(`https://graph.facebook.com/${graphVersion}/${userId}/media_publish`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: publishParams
  });
  const published = await publishResponse.json();
  if (!publishResponse.ok || !published.id) throw new Error(published.error?.message || 'Não foi possível publicar no Meta.');
  return published;
}

async function runCampaign(campaign) {
  campaign.status = 'sending';
  campaign.statusLabel = 'Enviando';
  campaign.sent = 0;
  campaignStore.save(campaign);
  try {
    campaign.sent = await sendToWhatsApp(campaign);
    if (campaign.publishedMeta) {
      await publishToMeta(campaign);
    }
    campaign.status = 'completed';
    campaign.statusLabel = 'Concluída';
    campaign.completedAt = new Date().toISOString();
  } catch (error) {
    campaign.status = 'error';
    campaign.statusLabel = 'Falhou';
    campaign.error = error.message;
  }
  campaignStore.save(campaign);
  return campaign;
}

app.get('/api/health', (_req, res) => {
  res.json({
    demoMode,
    wppconnect: demoMode || Boolean(process.env.WPP_CONNECT_URL && process.env.WPP_CONNECT_TOKEN),
    wppSession: String(process.env.WPP_CONNECT_SESSION || '').trim(),
    meta: demoMode || Boolean(process.env.META_IG_USER_ID && process.env.META_ACCESS_TOKEN),
    ai: aiConfigured
  });
});

app.get('/api/contacts', (_req, res) => res.json(contacts));

app.post('/api/contacts/import', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) return res.status(422).json({ error: 'Selecione uma planilha.' });
    const imported = await parseSpreadsheet(req.file);
    const unique = imported.filter((contact, index, list) => list.findIndex((item) => item.phone === contact.phone) === index);
    contacts.splice(0, contacts.length, ...unique);
    res.json({ count: contacts.length, contacts });
  } catch (error) {
    res.status(422).json({ error: `Não foi possível ler a planilha: ${error.message}` });
  }
});

app.post('/api/integrations/wppconnect/connect', async (req, res) => {
  const session = String(req.body.session || '').trim().replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 60);
  if (!session) return res.status(422).json({ error: 'Informe o nome da sessão.' });
  if (demoMode) return res.json({ status: 'awaiting_qr', demoMode: true, message: 'Modo demonstração: nenhum WhatsApp foi conectado.' });
  const configuredSession = String(process.env.WPP_CONNECT_SESSION || '').trim();
  if (configuredSession && session !== configuredSession) {
    return res.status(422).json({ error: `Use a sessão configurada no servidor: ${configuredSession}.` });
  }
  try {
    const base = String(process.env.WPP_CONNECT_URL || '').replace(/\/$/, '');
    const response = await fetch(`${base}/api/${encodeURIComponent(session)}/start-session`, { method: 'POST', headers: { Authorization: `Bearer ${process.env.WPP_CONNECT_TOKEN}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ waitQrCode: true }) });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) return res.status(response.status).json({ error: result.message || 'Não foi possível iniciar a sessão do WhatsApp.' });
    res.json({ status: 'awaiting_qr', qrCode: result.qrcode || result.qrCode || result.response?.qrcode || result.response?.qrCode || null });
  } catch (error) { res.status(502).json({ error: `WPPConnect indisponível: ${error.message}` }); }
});

app.get('/api/integrations/wppconnect/qr', async (req, res) => {
  const session = String(req.query.session || '').trim().replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 60);
  if (!session) return res.status(422).json({ error: 'Informe o nome da sessÃ£o.' });
  if (demoMode) return res.json({ qrCode: null, demoMode: true });
  try {
    const result = await wppGet('qrcode-session', session);
    res.json({ qrCode: result.qrcode || result.qrCode || result.base64QrCode || result.response || null });
  } catch (error) { res.status(502).json({ error: `NÃ£o foi possÃ­vel obter o QR Code: ${error.message}` }); }
});

app.get('/api/integrations/wppconnect/status', async (req, res) => {
  const session = String(req.query.session || '').trim().replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 60);
  if (!session) return res.status(422).json({ error: 'Informe o nome da sessão.' });
  if (demoMode) return res.json({ connected: false, status: 'DEMO', demoMode: true });
  const configuredSession = String(process.env.WPP_CONNECT_SESSION || '').trim();
  if (configuredSession && session !== configuredSession) {
    return res.status(422).json({ error: `Use a sessão configurada no servidor: ${configuredSession}.` });
  }
  try {
    const result = await wppGet('status-session', session);
    const status = String(result.status || 'UNKNOWN').toUpperCase();
    const connected = ['CONNECTED', 'OPEN', 'AUTHENTICATED', 'LOGGED', 'IN_CHAT'].some((value) => status.includes(value));
    res.json({ connected, status, session });
  } catch (error) { res.status(502).json({ error: `Não foi possível consultar o WhatsApp: ${error.message}` }); }
});

app.get('/api/integrations/wppconnect/contacts', async (req, res) => {
  const session = String(req.query.session || '').trim().replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 60);
  if (!session) return res.status(422).json({ error: 'Informe o nome da sessÃ£o.' });
  if (demoMode) return res.json({ count: 0, contacts: [], demoMode: true });
  try {
    const result = await wppGet('all-contacts', session);
    const extracted = unwrapWppResponse(result).map(normalizeWppContact).filter(Boolean);
    const unique = extracted.filter((contact, index, list) => list.findIndex((item) => item.phone === contact.phone) === index);
    contacts.splice(0, contacts.length, ...unique);
    res.json({ count: contacts.length, contacts });
  } catch (error) { res.status(502).json({ error: `NÃ£o foi possÃ­vel extrair os contatos: ${error.message}` }); }
});

app.post('/api/integrations/instagram/connect', async (req, res) => {
  const userId = String(req.body.userId || '').trim();
  const token = String(req.body.token || '').trim();
  if (!userId || !token) return res.status(422).json({ error: 'Informe o ID da conta e o token do Meta.' });
  if (demoMode) return res.json({ status: 'connected', demoMode: true, username: 'conta-demo' });
  try {
    const graphVersion = process.env.META_GRAPH_VERSION || 'v23.0';
    const params = new URLSearchParams({ fields: 'id,username', access_token: token });
    const response = await fetch(`https://graph.facebook.com/${graphVersion}/${encodeURIComponent(userId)}?${params}`);
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.id) return res.status(422).json({ error: result.error?.message || 'O Meta não validou esta conta ou token.' });
    res.json({ status: 'connected', username: result.username || result.id });
  } catch (error) { res.status(502).json({ error: `Meta indisponível: ${error.message}` }); }
});

app.get('/api/campaigns', (_req, res) => res.json(campaigns.map(({ recipients, media, channels, ...campaign }) => campaign)));

app.post('/api/campaigns', async (req, res) => {
  try {
    const validated = validateCampaign(req.body);
    const campaign = {
      id: crypto.randomUUID(),
      ...validated,
      media: req.body.media || null,
      audience: validated.recipients.length,
      sent: 0,
      publishedMeta: Boolean(req.body.publishedMeta),
      status: req.body.scheduledAt ? 'scheduled' : 'sending',
      statusLabel: req.body.scheduledAt ? 'Agendada' : 'Enviando',
      scheduledAt: req.body.scheduledAt || null,
      createdAt: 'Agora',
      color: req.body.type === 'image' ? '#d7f3ed' : req.body.type === 'video' ? '#eee5ff' : '#fff0d4'
    };
    campaigns.unshift(campaign);
    campaignStore.save(campaign);
    if (!campaign.scheduledAt) runCampaign(campaign);
    res.status(201).json({ id: campaign.id, status: campaign.status, demoMode });
  } catch (error) {
    res.status(422).json({ error: error.message });
  }
});

app.post('/api/campaigns/:id/launch', async (req, res) => {
  const campaign = campaigns.find((item) => item.id === req.params.id);
  if (!campaign) return res.status(404).json({ error: 'Campanha não encontrada.' });
  await runCampaign(campaign);
  res.json({ id: campaign.id, status: campaign.status, sent: campaign.sent, error: campaign.error });
});

setInterval(() => {
  const now = Date.now();
  campaigns
    .filter((campaign) => campaign.status === 'scheduled' && campaign.scheduledAt && Date.parse(campaign.scheduledAt) <= now)
    .forEach((campaign) => runCampaign(campaign));
}, 5000);

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, '..', 'public', 'index.html')));

app.listen(port, host, () => {
  console.log(`Major Neto rodando em http://localhost:${port} (${demoMode ? 'modo demonstração' : 'modo conectado'})`);
});

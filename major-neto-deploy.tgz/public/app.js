const state = {
  activeChannel: 'whatsapp',
  type: 'text',
  recipients: [],
  media: null,
  drafts: { whatsapp: { type: 'text', message: '', media: null }, instagram: { type: 'image', message: '', media: null } },
  campaigns: [],
  health: { demoMode: true },
  contactsFile: null
};

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const toast = (message) => { const element = $('#toast'); element.textContent = message; element.classList.add('show'); setTimeout(() => element.classList.remove('show'), 3200); };
let wppStatusTimer = null;

function setWhatsAppStatus(connected) {
  const badge = $('#whatsapp-page .integration-badge');
  if (badge) {
    badge.classList.toggle('pending', !connected);
    badge.classList.toggle('connected', connected);
    badge.innerHTML = `<i></i> ${connected ? 'Conectado' : 'Não conectado'}`;
  }
  const previewStatus = $('#preview-whatsapp-status');
  if (previewStatus) previewStatus.textContent = connected ? 'conectado' : 'não conectado';
  if (connected) {
    const qrContainer = $('#qr-placeholder');
    if (qrContainer) {
      qrContainer.replaceChildren();
      const icon = document.createElement('span');
      icon.textContent = '✓';
      const title = document.createElement('strong');
      title.textContent = 'Sessão conectada';
      const detail = document.createElement('small');
      detail.textContent = 'WhatsApp pronto para importar contatos e receber campanhas.';
      qrContainer.append(icon, title, detail);
    }
  }
}

async function checkWhatsAppStatus() {
  const session = state.wppSession || $('#wpp-session')?.value.trim() || state.health.wppSession;
  if (!session || state.health.demoMode) return setWhatsAppStatus(false);
  try {
    const response = await fetch(`/api/integrations/wppconnect/status?session=${encodeURIComponent(session)}`);
    const result = await response.json();
    setWhatsAppStatus(response.ok && result.connected === true);
  } catch { setWhatsAppStatus(false); }
}

function startWhatsAppStatusPolling() {
  if (wppStatusTimer) clearInterval(wppStatusTimer);
  void checkWhatsAppStatus();
  wppStatusTimer = setInterval(checkWhatsAppStatus, 5000);
}

function escapeHtml(value) { return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[char])); }
function formatCampaignType(type) { return type === 'image' ? ['▧', 'Imagem', 'type-image'] : type === 'video' ? ['▶', 'Vídeo', 'type-video'] : ['☷', 'Texto', 'type-text']; }
function formatStatus(status) { return status === 'completed' ? 'completed' : status === 'sending' ? 'sending' : status === 'scheduled' ? 'scheduled' : 'error'; }

function renderCampaigns() {
  $('#campaign-count').textContent = state.campaigns.length;
  if (!state.campaigns.length) {
    $('#campaign-table-body').innerHTML = '<tr><td colspan="7"><div class="empty-state"><strong>Nenhuma campanha criada</strong><span>Crie sua primeira campanha para acompanhar os disparos aqui.</span></div></td></tr>';
    return;
  }
  $('#campaign-table-body').innerHTML = state.campaigns.map((campaign) => {
    const [icon, label, typeClass] = formatCampaignType(campaign.type);
    return `<tr><td><div class="campaign-name-cell"><span class="campaign-thumb ${typeClass}">${icon}</span>${escapeHtml(campaign.name)}</div></td><td><div class="channel-cell"><span class="channel-dot">◉</span> WhatsApp ${campaign.publishedMeta ? '<span class="channel-dot meta">∞</span>' : ''}</div></td><td>${campaign.audience || 0} contatos</td><td>${campaign.sent || 0} / ${campaign.audience || 0}</td><td><span class="status-pill status-${formatStatus(campaign.status)}">${escapeHtml(campaign.statusLabel || label)}</span></td><td>${escapeHtml(campaign.createdAt || 'Agora')}</td><td><button class="row-menu" aria-label="Opções da campanha">•••</button></td></tr>`;
  }).join('');
}

function renderAudience() {
  const count = state.recipients.length;
  $('#audience-count').textContent = count ? `${count} contato${count === 1 ? '' : 's'} selecionado${count === 1 ? '' : 's'}` : 'Nenhum contato selecionado';
  $('#audience-subtitle').textContent = count ? 'Contatos adicionados manualmente' : 'Adicione contatos para começar';
  $('#audience-footnote').textContent = count ? `${count} contato${count === 1 ? '' : 's'} pronto${count === 1 ? '' : 's'} para receber` : 'Nenhum contato cadastrado';
  $('#audience-list').innerHTML = state.recipients.slice(0, 4).map((recipient, index) => `<span class="contact-avatar a${(index % 3) + 1}">${escapeHtml((recipient.name || '?').slice(0, 2).toUpperCase())}</span>`).join('');
  $('#audience-progress-bar').style.width = `${Math.min(count * 25, 100)}%`;
  $('#publish-button').disabled = !count;
  $('#contact-list').innerHTML = state.recipients.map((recipient) => `<div class="contact-row"><span class="list-icon">♧</span><span><strong>${escapeHtml(recipient.name)}</strong><small>${escapeHtml(recipient.phone)}</small></span></div>`).join('');
}

function saveDraft() {
  const publicUrl = $('#public-url')?.value.trim() || state.drafts[state.activeChannel].media?.publicUrl || '';
  state.drafts[state.activeChannel] = { type: state.type, message: $('#message').value, media: state.media ? { ...state.media, publicUrl } : null };
}

function loadDraft() {
  const draft = state.drafts[state.activeChannel];
  state.type = draft.type;
  state.media = draft.media;
  $$('.content-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.type === state.type));
  $('#upload-area').classList.toggle('hidden', state.type === 'text');
  if (state.type !== 'text' && !$('#public-url')) $('#upload-area').insertAdjacentHTML('beforeend', '<label class="field-label" for="public-url">URL pública da mídia <span style="color:#9aa5aa;font-weight:400">(necessária para o Meta conectado)</span></label><input class="text-input" id="public-url" type="url" placeholder="https://cdn.seusite.com/campanha.jpg" />');
  $('#message').value = draft.message || '';
  $('#message').placeholder = state.type === 'text' ? 'Escreva sua mensagem...' : 'Adicione uma legenda para sua mídia...';
  $('#upload-trigger').classList.toggle('hidden', Boolean(state.media));
  $('#file-preview').classList.toggle('hidden', !state.media);
  if (state.media) { $('#file-name').textContent = state.media.name; $('.file-type').textContent = state.type === 'image' ? 'IMG' : 'MP4'; if ($('#public-url')) $('#public-url').value = state.media.publicUrl || ''; }
  $('#active-channel-label').textContent = state.activeChannel === 'whatsapp' ? 'para WhatsApp' : 'para Instagram';
  updatePreview();
}

function switchChannel(channel) {
  if (channel === state.activeChannel) return;
  saveDraft();
  state.activeChannel = channel;
  $$('.channel-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.channel === channel));
  loadDraft();
}

function setType(type) {
  state.type = type;
  $$('.content-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.type === type));
  $('#upload-area').classList.toggle('hidden', type === 'text');
  if (type !== 'text' && !$('#public-url')) $('#upload-area').insertAdjacentHTML('beforeend', '<label class="field-label" for="public-url">URL pública da mídia <span style="color:#9aa5aa;font-weight:400">(necessária para o Meta conectado)</span></label><input class="text-input" id="public-url" type="url" placeholder="https://cdn.seusite.com/campanha.jpg" />');
  $('#message').placeholder = type === 'text' ? 'Escreva sua mensagem...' : 'Adicione uma legenda para sua mídia...';
  updatePreview();
}

function updatePreview() {
  saveDraft();
  const message = ($('#message').value || 'Escreva uma mensagem...').replace(/\\n/g, '\n');
  $('#char-count').textContent = `${message.length} / 4096`;
  const plain = escapeHtml(message).replace(/\n/g, '<br>');
  const media = state.media ? `<div style="background:#bde5da;border-radius:5px;padding:8px;margin-bottom:6px;color:#28796c;font-size:9px">${state.type === 'video' ? '▶ Vídeo anexado' : '▧ Imagem anexada'}</div>` : '';
  $('#preview-bubble').innerHTML = `${media}<span>${plain}</span><small>09:42 ✓✓</small>`;
}

function fileToDataUrl(file) { return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(reader.result); reader.onerror = reject; reader.readAsDataURL(file); }); }

async function handleFile(file) {
  if (!file) return;
  if (file.size > 15 * 1024 * 1024) return toast('O arquivo precisa ter no máximo 15 MB.');
  const allowed = state.type === 'image' ? file.type.startsWith('image/') : file.type.startsWith('video/');
  if (!allowed) return toast(`Selecione um arquivo de ${state.type === 'image' ? 'imagem' : 'vídeo'}.`);
  state.media = { name: file.name, base64: await fileToDataUrl(file), mimeType: file.type };
  $('#upload-trigger').classList.add('hidden');
  $('#file-preview').classList.remove('hidden');
  $('#file-name').textContent = file.name;
  $('.file-type').textContent = state.type === 'image' ? 'IMG' : 'MP4';
  updatePreview();
}

async function loadData() {
  try {
    const [healthResponse, campaignsResponse] = await Promise.all([fetch('/api/health'), fetch('/api/campaigns')]);
    state.health = await healthResponse.json();
    state.campaigns = await campaignsResponse.json();
    const sessionInput = $('#wpp-session');
    if (sessionInput && !sessionInput.value && state.health.wppSession) sessionInput.value = state.health.wppSession;
    state.wppSession = state.wppSession || state.health.wppSession || '';
    startWhatsAppStatusPolling();
    const aiToggle = $('#ai-personalization');
    if (aiToggle) {
      aiToggle.disabled = !state.health.ai;
      $('#ai-status').textContent = state.health.ai ? 'Token configurado no servidor' : 'Configure AI_API_KEY no .env';
    }
    $('#status-text').textContent = state.health.demoMode ? 'Modo demonstração' : 'Tudo operando';
  } catch { $('#status-text').textContent = 'Modo local'; }
  renderCampaigns();
}

async function publishCampaign() {
  saveDraft();
  const name = $('#campaign-name').value.trim();
  const whatsapp = state.drafts.whatsapp;
  const instagram = state.drafts.instagram;
  const selectedSchedule = $('input[name="schedule"]:checked').value;
  const scheduledAt = selectedSchedule === 'later' ? `${$('#schedule-date').value}T${$('#schedule-time').value}` : null;
  if (!state.recipients.length) return toast('Adicione ao menos um contato ao público.');
  if (!name || (!whatsapp.message.trim() && !whatsapp.media)) return toast('Preencha o nome e o conteúdo do WhatsApp.');
  if ($('#meta-toggle').checked && !instagram.media) return toast('Adicione uma imagem ou vídeo para publicar no Instagram.');
  if (selectedSchedule === 'later' && !$('#schedule-date').value) return toast('Escolha uma data para agendar.');
  const button = $('#publish-button'); button.disabled = true; button.innerHTML = '<span>◌</span> Publicando...';
  try {
    const response = await fetch('/api/campaigns', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name, type: whatsapp.type, message: whatsapp.message, recipients: state.recipients, media: whatsapp.media, channels: { whatsapp, instagram }, wppSession: $('#wpp-session')?.value.trim() || '', delayMs: Number($('#message-delay').value) * 1000, aiPersonalization: $('#ai-personalization').checked, publishedMeta: $('#meta-toggle').checked, scheduledAt }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Não foi possível criar a campanha.');
    toast(scheduledAt ? 'Campanha agendada com sucesso.' : (state.health.demoMode ? 'Campanha simulada com sucesso.' : 'Campanha publicada com sucesso.'));
    await new Promise((resolve) => setTimeout(resolve, 500));
    await loadData();
  } catch (error) { toast(error.message); }
  finally { button.disabled = false; button.innerHTML = '<span>↗</span> Publicar campanha'; }
}

function showPage(view) {
  $$('.page-view').forEach((page) => page.classList.toggle('hidden', page.id !== `${view}-page`));
  $$('.nav-item').forEach((item) => item.classList.toggle('active', item.dataset.view === view));
  const labels = { campaigns: 'Campanhas', whatsapp: 'WhatsApp', instagram: 'Instagram' };
  $('#breadcrumb-current').textContent = labels[view];
}

function handleContactsFile(file) {
  if (!file) return;
  if (file.size > 10 * 1024 * 1024) return toast('A planilha precisa ter no máximo 10 MB.');
  state.contactsFile = file;
  $('#contacts-file-name').textContent = file.name;
  $('#imported-file').classList.remove('hidden');
  $('#contacts-upload').classList.add('hidden');
  $('#import-contacts').disabled = false;
}

async function importContacts() {
  if (!state.contactsFile) return;
  const formData = new FormData();
  formData.append('file', state.contactsFile);
  const button = $('#import-contacts'); button.disabled = true; button.textContent = 'Importando...';
  try {
    const response = await fetch('/api/contacts/import', { method: 'POST', body: formData });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Não foi possível importar os contatos.');
    state.recipients = result.contacts || [];
    renderAudience();
    toast(`${result.count} contato${result.count === 1 ? '' : 's'} importado${result.count === 1 ? '' : 's'}.`);
  } catch (error) { toast(error.message); }
  finally { button.disabled = false; button.textContent = 'Importar contatos'; }
}

async function connectWhatsApp(trigger = $('#connect-whatsapp')) {
  const session = $('#wpp-session').value.trim();
  if (!session) return toast('Informe um nome para a sessão.');
  const buttons = [$('#connect-whatsapp'), $('#refresh-qr')].filter(Boolean);
  buttons.forEach((button) => { button.disabled = true; });
  trigger.textContent = trigger.id === 'refresh-qr' ? 'Atualizando...' : 'Gerando...';
  try {
    const response = await fetch('/api/integrations/wppconnect/connect', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ session }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Não foi possível conectar o WhatsApp.');
    toast(result.demoMode ? 'Conexão simulada — configure o .env para usar o WhatsApp real.' : 'Sessão iniciada.');
    state.wppSession = session;
    renderQr(result.qrCode, result.demoMode);
    void checkWhatsAppStatus();
  } catch (error) { toast(error.message); }
  finally {
    buttons.forEach((button) => { button.disabled = false; });
    $('#connect-whatsapp').textContent = 'Gerar QR Code';
    $('#refresh-qr').textContent = '↻ Atualizar QR Code';
  }
}

function renderQr(qrCode, isDemo = false) {
  const container = $('#qr-placeholder');
  container.replaceChildren();
  if (qrCode && String(qrCode).startsWith('data:image/')) {
    const image = document.createElement('img');
    image.src = qrCode;
    image.alt = 'QR Code para conectar o WhatsApp';
    image.className = 'qr-image';
    const detail = document.createElement('small');
    detail.textContent = `QR gerado às ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}. Se aparecer "verificar", atualize e escaneie novamente.`;
    container.append(image, detail);
    return;
  }
  const icon = document.createElement('span');
  icon.textContent = isDemo ? '✓' : '¦';
  const title = document.createElement('strong');
  title.textContent = isDemo ? 'Sessão iniciada' : 'QR Code aguardando';
  const detail = document.createElement('small');
  detail.textContent = isDemo ? 'Modo demonstração: nenhuma conta foi conectada.' : 'Se o QR não aparecer, clique novamente em Gerar QR Code.';
  container.append(icon, title, detail);
}

async function extractContacts() {
  const session = $('#wpp-session').value.trim();
  if (!session) return toast('Informe e conecte uma sessão do WhatsApp primeiro.');
  const button = $('#extract-contacts'); button.disabled = true; button.textContent = 'Extraindo...';
  try {
    const response = await fetch(`/api/integrations/wppconnect/contacts?session=${encodeURIComponent(session)}`);
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Não foi possível extrair os contatos.');
    state.recipients = result.contacts || [];
    renderAudience();
    toast(result.demoMode ? 'Nenhum contato extraído no modo demonstração.' : `${result.count} contato${result.count === 1 ? '' : 's'} extraído${result.count === 1 ? '' : 's'}.`);
  } catch (error) { toast(error.message); }
  finally { button.disabled = false; button.textContent = 'Extrair contatos do WhatsApp'; }
}

const campaignControls = document.createElement('div');
campaignControls.className = 'campaign-controls';
const delayLabel = document.createElement('label');
delayLabel.className = 'field-label';
delayLabel.textContent = 'Intervalo entre mensagens (segundos)';
const delayInput = document.createElement('input');
delayInput.type = 'number';
delayInput.id = 'message-delay';
delayInput.className = 'text-input';
delayInput.min = '1';
delayInput.max = '600';
delayInput.step = '1';
delayInput.value = '3';
delayLabel.htmlFor = delayInput.id;
const aiLabel = document.createElement('label');
aiLabel.className = 'ai-option';
const aiToggle = document.createElement('input');
aiToggle.type = 'checkbox';
aiToggle.id = 'ai-personalization';
aiLabel.append(aiToggle, document.createTextNode(' Personalizar a mensagem com IA'));
const aiStatus = document.createElement('small');
aiStatus.id = 'ai-status';
aiStatus.textContent = 'Configure AI_API_KEY no .env';
campaignControls.append(delayLabel, delayInput, aiLabel, aiStatus);
$('#publish-button').insertAdjacentElement('beforebegin', campaignControls);

const extractButton = document.createElement('button');
extractButton.type = 'button';
extractButton.id = 'extract-contacts';
extractButton.className = 'button button-primary full-width';
extractButton.textContent = 'Extrair contatos do WhatsApp';
$('#import-contacts').insertAdjacentElement('afterend', extractButton);

$$('.content-tab').forEach((tab) => tab.addEventListener('click', () => setType(tab.dataset.type)));
$('#message').addEventListener('input', updatePreview);
$('#new-campaign-button').addEventListener('click', () => { $('#campaign-composer').scrollIntoView({ behavior: 'smooth', block: 'start' }); $('#campaign-name').focus(); });
$('#publish-button').addEventListener('click', publishCampaign);
$('#upload-trigger').addEventListener('click', () => $('#media-file').click());
$('#media-file').addEventListener('change', (event) => handleFile(event.target.files[0]));
$('#remove-file').addEventListener('click', () => { state.media = null; $('#media-file').value = ''; $('#upload-trigger').classList.remove('hidden'); $('#file-preview').classList.add('hidden'); updatePreview(); });
['dragenter', 'dragover'].forEach((eventName) => $('#upload-area').addEventListener(eventName, (event) => { event.preventDefault(); $('#upload-area').classList.add('dragging'); }));
['dragleave', 'drop'].forEach((eventName) => $('#upload-area').addEventListener(eventName, (event) => { event.preventDefault(); $('#upload-area').classList.remove('dragging'); }));
$('#upload-area').addEventListener('drop', (event) => handleFile(event.dataTransfer.files[0]));
$$('input[name="schedule"]').forEach((input) => input.addEventListener('change', () => { $$('.schedule-option').forEach((option) => option.classList.toggle('selected', option.querySelector('input').checked)); $('#datetime-row').classList.toggle('hidden', input.value !== 'later' || !input.checked); }));
$('#open-contacts').addEventListener('click', () => $('#contacts-modal').classList.remove('hidden'));
$('#edit-audience').addEventListener('click', () => $('#contacts-modal').classList.remove('hidden'));
$('#close-contacts').addEventListener('click', () => $('#contacts-modal').classList.add('hidden'));
$('#add-contact').addEventListener('click', () => {
  const name = $('#contact-name').value.trim();
  const phone = $('#contact-phone').value.replace(/\D/g, '');
  if (!name || phone.length < 8) return toast('Informe nome e WhatsApp com DDI.');
  if (state.recipients.some((recipient) => recipient.phone === phone)) return toast('Este contato já foi adicionado.');
  state.recipients.push({ name, phone });
  $('#contact-name').value = '';
  $('#contact-phone').value = '';
  renderAudience();
  toast('Contato adicionado ao público.');
});
$('#save-contacts').addEventListener('click', () => { $('#contacts-modal').classList.add('hidden'); toast(state.recipients.length ? 'Público atualizado.' : 'Nenhum contato foi selecionado.'); });
$('#meta-settings').addEventListener('click', () => toast('As credenciais do Meta são configuradas no arquivo .env.'));
$$('.channel-tab').forEach((tab) => tab.addEventListener('click', () => switchChannel(tab.dataset.channel)));
$$('.nav-item').forEach((item) => item.addEventListener('click', () => showPage(item.dataset.view)));
$('#contacts-upload').addEventListener('click', () => $('#contacts-file').click());
$('#contacts-file').addEventListener('change', (event) => handleContactsFile(event.target.files[0]));
$('#remove-contacts-file').addEventListener('click', () => { state.contactsFile = null; $('#contacts-file').value = ''; $('#contacts-upload').classList.remove('hidden'); $('#imported-file').classList.add('hidden'); $('#import-contacts').disabled = true; });
$('#import-contacts').addEventListener('click', importContacts);
$('#extract-contacts').addEventListener('click', extractContacts);
$('#connect-whatsapp').addEventListener('click', () => connectWhatsApp());
$('#refresh-qr').addEventListener('click', (event) => connectWhatsApp(event.currentTarget));
$('#connect-instagram').addEventListener('click', async () => {
  const userId = $('#instagram-user-id').value.trim();
  const token = $('#instagram-token').value.trim();
  if (!userId || !token) return toast('Informe o ID da conta e o token do Meta.');
  const button = $('#connect-instagram'); button.disabled = true; button.textContent = 'Validando...';
  try {
    const response = await fetch('/api/integrations/instagram/connect', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId, token }) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || 'Não foi possível conectar o Instagram.');
    $('.instagram-connect-card .helper-text').textContent = `Conta conectada: @${result.username}. O token não é armazenado pelo painel.`;
    $('.instagram-preview-card small').textContent = `@${result.username}`;
    $('.instagram-empty strong').textContent = 'Conta conectada';
    $('.instagram-empty small').textContent = 'A publicação automática está pronta para uso.';
    toast(result.demoMode ? 'Conta simulada. Configure o .env para publicar no Meta.' : 'Instagram conectado com sucesso.');
  } catch (error) { toast(error.message); }
  finally { button.disabled = false; button.textContent = 'Conectar conta do Instagram'; }
});
if ($('#message').value.includes('\\n')) $('#message').value = $('#message').value.replace(/\\n/g, '\n');
renderAudience(); updatePreview(); loadData();

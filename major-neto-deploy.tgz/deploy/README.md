# Deploy seguro na VPS

O deploy foi preparado para Ubuntu 22.04/24.04 com Node.js 22 LTS, systemd, Nginx, HTTPS e autenticação HTTP. As portas internas `3000` e `21465` devem permanecer fechadas na internet.

## Antes de começar

1. Aponte um registro DNS `A` do seu domínio para o IP da VPS.
2. Tenha acesso SSH por chave, não por senha compartilhada.
3. Reserve um usuário Linux sem privilégios de root para o sistema.
4. Separe os segredos: token do WPPConnect, token Meta e token de IA.

## Preparar a VPS

```bash
sudo apt update
sudo apt install -y nginx certbot python3-certbot-nginx apache2-utils ufw fail2ban
sudo adduser --system --group --home /opt/major-neto major-neto
sudo mkdir -p /opt/major-neto/data /opt/major-neto/uploads /opt/major-neto/log /opt/wppconnect /etc/major-neto /var/www/html
sudo chown -R major-neto:major-neto /opt/major-neto /opt/wppconnect
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw --force enable
sudo systemctl enable --now fail2ban
```

Instale Node.js 22 LTS e o servidor WPPConnect conforme a documentação da distribuição. Depois:

```bash
sudo npm install -g @wppconnect/server-cli
```

Copie o projeto para `/opt/major-neto` sem enviar `.env`, `node_modules`, `tokens`, `userDataDir` ou `WhatsAppImages`:

```bash
sudo -u major-neto npm ci --omit=dev --prefix /opt/major-neto
```

## Segredos fora do código

Crie `/etc/major-neto/wpp.env` com permissão `600`:

```ini
SECRET_KEY=gere-uma-chave-aleatoria-longa
```

Crie `/etc/major-neto/app.env` com permissão `600`:

```ini
NODE_ENV=production
PORT=3000
HOST=127.0.0.1
DATABASE_PATH=/opt/major-neto/data/major-neto.sqlite
DEMO_MODE=false
WPP_CONNECT_URL=http://127.0.0.1:21465
WPP_CONNECT_SESSION=major
WPP_CONNECT_TOKEN=
META_GRAPH_VERSION=v23.0
META_IG_USER_ID=
META_ACCESS_TOKEN=
AI_BASE_URL=https://api.openai.com/v1
AI_MODEL=gpt-4o-mini
AI_API_KEY=
```

```bash
sudo chmod 600 /etc/major-neto/*.env
sudo chown root:root /etc/major-neto/*.env
```

## Subir os serviços

```bash
sudo cp deploy/wppconnect.service /etc/systemd/system/
sudo cp deploy/major-neto.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now wppconnect.service
```

Gere o token da sessão usando a `SECRET_KEY` diretamente na VPS. Não cole o token em chat, Git ou logs. Grave somente o valor do campo `token` em `WPP_CONNECT_TOKEN`:

```bash
curl -X POST http://127.0.0.1:21465/api/major/SUA_SECRET_KEY/generate-token
sudo systemctl restart wppconnect.service
sudo systemctl enable --now major-neto.service
```

Verifique sem expor segredos:

```bash
curl http://127.0.0.1:3000/api/health
curl http://127.0.0.1:21465/healthz
sudo journalctl -u major-neto -n 100 --no-pager
sudo journalctl -u wppconnect -n 100 --no-pager
```

## Nginx, senha e HTTPS

```bash
sudo htpasswd -c /etc/nginx/.htpasswd-major-neto administrador
sudo cp deploy/nginx-major-neto.conf.example /etc/nginx/sites-available/major-neto
sudo sed -i 's/SEU_DOMINIO/seu.dominio.com.br/g' /etc/nginx/sites-available/major-neto
sudo ln -s /etc/nginx/sites-available/major-neto /etc/nginx/sites-enabled/major-neto
sudo nginx -t
sudo systemctl reload nginx
sudo certbot --nginx -d seu.dominio.com.br
```

A senha do painel é criada diretamente na VPS pelo `htpasswd`; ela não deve ser enviada para o agente. Depois do certificado, teste `https://seu.dominio.com.br` e mantenha `3000` e `21465` bloqueadas pelo firewall.

## Rollback

Antes de atualizar, faça uma cópia do diretório da aplicação. Em caso de erro:

```bash
sudo systemctl stop major-neto
sudo rsync -a --delete /opt/major-neto-backup/ /opt/major-neto/
sudo systemctl start major-neto
curl -u administrador https://seu.dominio.com.br/api/health
```
